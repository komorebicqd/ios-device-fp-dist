# DeviceFingerprintSDK 离线接入说明

## 交付内容

- `DeviceFingerprintSDK.xcframework`：已编译的设备指纹 SDK，无需源码、GitHub 仓库或 Swift Package Manager。
- `SHA256SUMS.txt`：真机与模拟器二进制的 SHA-256 校验值。

## 环境要求

- 最低系统版本：iOS 13.0。
-  Xcode：建议 16.4 或更高版本。当前框架使用 Xcode 16.4 / Swift 6.1.2 构建，采用 Swift 5 语言模式。
- 真机：arm64。
- 模拟器：arm64（Apple Silicon）与 x86_64（Intel）。

## 一、添加到 Xcode 工程

1. 解压本交付 ZIP，得到 `DeviceFingerprintSDK.xcframework`。
2. 使用 Xcode 打开商户 App 工程，选择 App Target。
3. 进入 **General → Frameworks, Libraries, and Embedded Content**。
4. 点击 `+`，选择 **Add Other → Add Files…**。
5. 选择最外层的 `DeviceFingerprintSDK.xcframework`。
6. 将 `DeviceFingerprintSDK.xcframework` 设置为 **Embed & Sign**。

注意：请添加最外层的 `.xcframework`，不要单独添加 `ios-arm64` 或 `ios-arm64_x86_64-simulator` 目录中的 `.framework`。Xcode 会根据构建目标自动选择正确切片。

## 二、初始化并获取 deviceId

在 App 启动阶段初始化一次，`appId` 使用服务方分配的标识，`baseURL` 使用对应环境的服务地址：

```swift
import DeviceFingerprintSDK

FingerprintSDK.configure(
    appId: "your-app-id",
    baseURL: "https://api.example.com"
)

FingerprintSDK.getDeviceId { result in
    // 回调不保证在主线程；更新 UI 时切换到主线程。
    DispatchQueue.main.async {
        switch result {
        case .success(let deviceId):
            print("deviceId: \(deviceId)")
        case .failure(let error):
            print("获取 deviceId 失败: \(error.localizedDescription)")
        }
    }
}
```

也支持 async/await：

```swift
import DeviceFingerprintSDK

Task {
    do {
        let deviceId = try await FingerprintSDK.getDeviceId()
        print("deviceId: \(deviceId)")
    } catch {
        print("获取 deviceId 失败: \(error.localizedDescription)")
    }
}
```

生产环境请使用 HTTPS 服务地址。SDK 会优先使用本地缓存；冷启动时的并发调用会共享同一次初始化与指纹生成流程。

## 三、校验二进制（可选）

在 macOS 终端进入解压后的目录，执行：

```bash
shasum -a 256 -c SHA256SUMS.txt
```

两个二进制均显示 `OK` 即表示文件完整。

## 常见问题

### `No such module 'DeviceFingerprintSDK'`

确认 `.xcframework` 已添加到当前 App Target 的 **Frameworks, Libraries, and Embedded Content**，并且设置不为空。

### 真机或模拟器链接错误

确认添加的是最外层 `.xcframework`，不是某个架构目录中的 `.framework`，然后执行 **Product → Clean Build Folder** 后重新构建。

### 本地 HTTP 联调无法访问

真机访问局域网服务时，App 的 Info.plist 需要配置 `NSLocalNetworkUsageDescription`。该说明仅用于本地联调，生产环境请使用 HTTPS。
